### Follow the principle of the following link
https://github.com/alexeymezenin/laravel-best-practices

### API Docs
Use postman for handwriting api docs

### Restfull api standard
https://www.restapitutorial.com/httpstatuscodes.html
https://jsonapi.org/
