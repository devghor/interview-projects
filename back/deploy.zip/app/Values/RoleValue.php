<?php

namespace App\Values;

class RoleValue
{
    const SUPER_ADMIN_ID = 1;
    const SUPER_ADMIN_NAME = 'superadmin';
    const STAFF_ADMIN_ID = 2;
    const STAFF_ADMIN_NAME = 'staffadmin';
}
